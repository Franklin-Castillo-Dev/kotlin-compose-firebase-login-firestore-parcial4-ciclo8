package com.example.di.navigation.moduloroomdinavcompose.compose

import android.util.Log
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable



@Composable
internal fun EighthScreen(arg:String?){

        Text(text = "EighthScreen arg =${arg}")


}