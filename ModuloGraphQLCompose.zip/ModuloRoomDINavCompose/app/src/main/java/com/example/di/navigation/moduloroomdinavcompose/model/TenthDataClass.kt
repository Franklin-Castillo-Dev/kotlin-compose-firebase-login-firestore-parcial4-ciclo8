package com.example.di.navigation.moduloroomdinavcompose.model

data class TenthDataClass (val id:String,var name:String,var description:String)
