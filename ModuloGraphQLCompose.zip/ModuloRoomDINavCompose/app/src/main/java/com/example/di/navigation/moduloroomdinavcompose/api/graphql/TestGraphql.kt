package com.example.di.navigation.moduloroomdinavcompose.api.graphql

class TestGraphql {
}